# Echoglossian CN Fork Kit

This is a **fork-preparation kit** for making a custom Echoglossian fork that is easier to install through Dalamud as a separate custom plugin entry.

It does not contain or redistribute Echoglossian source code. You apply it after you fork/clone `lokinmodar/Echoglossian`.

## What this kit changes

- Renames the plugin metadata from `Echoglossian` to `Echoglossian CN`.
- Changes `InternalName` to `EchoglossianCN` so Dalamud treats it as a separate plugin entry.
- Changes the output assembly name to `EchoglossianCN` when possible.
- Changes chat commands from `/eglo` and `/eglodbmanager` to `/eglocn` and `/eglocndbmanager` to avoid conflicts if regular Echoglossian is also installed.
- Provides a custom Dalamud repo JSON template.
- Provides a GitHub Actions workflow template for release builds.
- Adds an optional Mandarin tooltip overlay patch for item/action tooltip hovers.

## Important notes

- This is not an official Square Enix or XIVLauncher/Dalamud plugin.
- This does not add official Chinese game files or official Chinese-region text assets.
- Before public distribution, verify Echoglossian's license terms. The repository-level `LICENSE.txt` currently says CC BY 4.0, while some source headers in the v4-series branch mention a different Creative Commons license. Keep attribution and clarify permission before publishing widely.
- If you submit anything to the official Dalamud plugin repository, disclose AI assistance and follow Dalamud's current submission rules.

## Fast path

1. Fork Echoglossian on GitHub.
2. Clone your fork:

   ```powershell
   git clone https://github.com/YOUR_GITHUB_USERNAME/Echoglossian.git EchoglossianCN
   cd EchoglossianCN
   git checkout v4-series
   ```

3. Copy this kit's `tools/Convert-ToEchoglossianCN.ps1` into the repo root.
4. Run:

   ```powershell
   pwsh ./Convert-ToEchoglossianCN.ps1 -GitHubUser YOUR_GITHUB_USERNAME
   ```

5. Commit and push:

   ```powershell
   git add .
   git commit -m "Create Echoglossian CN fork metadata"
   git push origin v4-series
   ```

6. Build locally or use the GitHub Actions workflow included in this kit.
7. Publish the release zip and update `repo/pluginmaster.json` with the correct release URL, assembly version, timestamp, and Dalamud API level.
8. Add the raw `pluginmaster.json` URL in-game through `/xlsettings` → Experimental → Custom Plugin Repositories.


## Tooltip overlay patch

This v2 kit includes a separate overlay module for translating item/action tooltip hovers. It intentionally **does not rewrite FFXIV's native tooltip window**. Instead, it reads the hovered item/action using Dalamud hover APIs, translates the English Lumina row text through Echoglossian's existing translation service, caches the result, and draws a small Chinese overlay next to the cursor.

After running the fork-conversion script, apply the overlay from the Echoglossian repo root:

```powershell
pwsh /path/to/echoglossian-cn-fork-kit-v2/tools/Add-CnTooltipOverlay.ps1 -RepoRoot .
dotnet build .\Echoglossian.csproj -c Release
```

More details are in `docs/TOOLTIP_OVERLAY.md`.

## Mandarin defaults

This kit does **not hard-code a target-language ID**, because Echoglossian's language IDs can change and I do not want to give you a brittle default that silently selects the wrong language. For the first usable version, install the fork, open `/eglocn`, and set the target to Simplified Chinese or Traditional Chinese in the UI.

A later code pass can add a safer first-run wizard like:

- preferred script: Simplified Chinese / Traditional Chinese
- preferred backend: OpenAI-compatible / DeepL / Google / Microsoft / local LLM
- translation surfaces: Talk, BattleTalk, TalkSubtitle, MiniTalk, Quest/Journal, toasts

## Recommended plugin settings for a girlfriend-friendly setup

- Target language: Simplified Chinese, unless she specifically prefers Traditional Chinese.
- Enable: Talk, BattleTalk, TalkSubtitle, MiniTalk, quest/journal text, quest toasts.
- Disable initially: tooltips, item/action detail replacement, anything marked unstable.
- Use native replacement where readable; use overlay mode if font rendering breaks.
- Add a glossary/prompt for FFXIV terms if using an LLM backend.

