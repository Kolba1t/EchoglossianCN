param(
    [Parameter(Mandatory=$true)]
    [string]$GitHubUser,

    [string]$PluginName = "Echoglossian CN",
    [string]$InternalName = "EchoglossianCN",
    [string]$RepoName = "EchoglossianCN"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Info($msg) { Write-Host "[EchoglossianCN] $msg" }

$root = Get-Location
$manifestPath = Join-Path $root "Echoglossian.json"
$csprojPath = Join-Path $root "Echoglossian.csproj"
$mainPluginPath = Join-Path $root "Echoglossian.cs"

if (!(Test-Path $manifestPath)) { throw "Echoglossian.json not found. Run this from the Echoglossian repo root." }
if (!(Test-Path $csprojPath)) { throw "Echoglossian.csproj not found. Run this from the Echoglossian repo root." }
if (!(Test-Path $mainPluginPath)) { throw "Echoglossian.cs not found. Run this from the Echoglossian repo root." }

Write-Info "Updating Dalamud manifest metadata..."
$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
$manifest.Name = $PluginName
$manifest.InternalName = $InternalName
$manifest.Author = "$GitHubUser, based on lokinmodar/Echoglossian"
$manifest.Description = "Realtime game text translator preset/fork for Mandarin Chinese users on global FFXIV clients."
$manifest.RepoUrl = "https://github.com/$GitHubUser/$RepoName"
$manifest.Punchline = "Mandarin-focused fork of Echoglossian for dialogue and in-game text translation."
$manifest.Tags = @("ffxiv", "Dalamud", "plugin", "translation", "Chinese", "Mandarin", "UI", "Utility")
$manifest | ConvertTo-Json -Depth 10 | Set-Content $manifestPath -Encoding UTF8

Write-Info "Updating project metadata where possible..."
$csproj = Get-Content $csprojPath -Raw
$csproj = $csproj -replace '<AssemblyName>Echoglossian</AssemblyName>', "<AssemblyName>$InternalName</AssemblyName>"
$csproj = $csproj -replace '<Product>Echoglossian</Product>', "<Product>$PluginName</Product>"
$csproj = $csproj -replace '<PackageProjectUrl>https://github.com/lokinmodar/Echoglossian/?</PackageProjectUrl>', "<PackageProjectUrl>https://github.com/$GitHubUser/$RepoName</PackageProjectUrl>"
$csproj = $csproj -replace '<RepositoryUrl>https://github.com/lokinmodar/Echoglossian/?</RepositoryUrl>', "<RepositoryUrl>https://github.com/$GitHubUser/$RepoName</RepositoryUrl>"
$csproj | Set-Content $csprojPath -Encoding UTF8

Write-Info "Changing slash commands to avoid conflicts with regular Echoglossian..."
$main = Get-Content $mainPluginPath -Raw
$main = $main -replace 'private const string SlashCommand = "/eglo";', 'private const string SlashCommand = "/eglocn";'
$main = $main -replace 'private const string DBManagerWindowCommand = "/eglodbmanager";', 'private const string DBManagerWindowCommand = "/eglocndbmanager";'
$main = $main -replace 'private const string AddonProbeCommand = "/egloaddonprobe";', 'private const string AddonProbeCommand = "/eglocnaddonprobe";'
$main = $main -replace 'private const string QuestProbeCommand = "/egloquestprobe";', 'private const string QuestProbeCommand = "/eglocnquestprobe";'
$main | Set-Content $mainPluginPath -Encoding UTF8

Write-Info "Creating local fork notes..."
@"
# Echoglossian CN fork notes

This fork was prepared with the Echoglossian CN fork kit.

Commands:

- /eglocn opens plugin config
- /eglocndbmanager opens the translation DB manager

Set target language to Simplified Chinese or Traditional Chinese in the config window.

Original project: https://github.com/lokinmodar/Echoglossian
"@ | Set-Content (Join-Path $root "FORK_NOTES_CN.md") -Encoding UTF8

Write-Info "Done. Review git diff before committing."
