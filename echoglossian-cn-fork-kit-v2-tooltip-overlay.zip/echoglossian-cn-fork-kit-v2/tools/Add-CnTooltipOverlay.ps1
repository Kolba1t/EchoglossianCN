param(
    [string]$RepoRoot = (Get-Location).Path
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Info($msg) { Write-Host "[EchoglossianCN TooltipOverlay] $msg" }

$repoRoot = (Resolve-Path $RepoRoot).Path
$scriptRoot = Split-Path -Parent $PSCommandPath
$kitRoot = Split-Path -Parent $scriptRoot
$sourceDir = Join-Path $kitRoot "src/TooltipOverlay"
$targetDir = Join-Path $repoRoot "TooltipOverlay"
$pluginPath = Join-Path $repoRoot "Echoglossian.cs"
$configPath = Join-Path $repoRoot "Config.cs"

if (!(Test-Path $sourceDir)) { throw "Tooltip overlay source not found at $sourceDir. Run this script from the extracted kit, or keep the kit's src/TooltipOverlay folder next to tools/." }
if (!(Test-Path $pluginPath)) { throw "Echoglossian.cs not found in $repoRoot. Pass -RepoRoot or run from the Echoglossian repo root." }
if (!(Test-Path $configPath)) { throw "Config.cs not found in $repoRoot. Pass -RepoRoot or run from the Echoglossian repo root." }

Write-Info "Copying overlay source files..."
New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
Copy-Item -Path (Join-Path $sourceDir "*.cs") -Destination $targetDir -Force

Write-Info "Patching Config.cs with overlay settings..."
$config = Get-Content $configPath -Raw
if ($config -notmatch 'TranslateTooltipOverlay') {
    $configFields = @'

    [DefaultValue(true)]
    public bool TranslateTooltipOverlay = true;

    [DefaultValue(false)]
    public bool TooltipOverlayShowOriginal = false;

    [DefaultValue(350)]
    public int TooltipOverlayDelayMs = 350;

    [DefaultValue(560)]
    public int TooltipOverlayMaxWidth = 560;

    [DefaultValue(1.0f)]
    public float TooltipOverlayFontScale = 1.0f;

    [DefaultValue(0.96f)]
    public float TooltipOverlayBgAlpha = 0.96f;
'@

    if ($config -match '\[DefaultValue\(false\)\]\s*public bool TranslateTooltips = false;') {
        $config = $config -replace '(\[DefaultValue\(false\)\]\s*public bool TranslateTooltips = false;)', "`$1$configFields"
    }
    elseif ($config -match 'public bool Translate = true;') {
        $config = $config -replace '(public bool Translate = true;)', "`$1$configFields"
    }
    else {
        throw "Could not find a safe insertion point in Config.cs. Add the fields from docs/TOOLTIP_OVERLAY.md manually."
    }

    Set-Content $configPath $config -Encoding UTF8
}
else {
    Write-Info "Config.cs already has overlay settings; skipping."
}

Write-Info "Patching Echoglossian.cs startup/dispose hooks..."
$plugin = Get-Content $pluginPath -Raw
if ($plugin -notmatch 'RegisterCnTooltipOverlayRuntime\(') {
    if ($plugin -match 'this\.RebuildTranslationServiceSafely\(\);') {
        $plugin = $plugin -replace '(this\.RebuildTranslationServiceSafely\(\);)', "`$1`r`n            this.RegisterCnTooltipOverlayRuntime();"
    }
    elseif ($plugin -match 'TranslationService =') {
        throw "Could not find RebuildTranslationServiceSafely(); Add this.RegisterCnTooltipOverlayRuntime(); after translation service initialization."
    }
    else {
        throw "Could not find a safe constructor insertion point in Echoglossian.cs."
    }
}
else {
    Write-Info "Startup hook already exists; skipping."
}

if ($plugin -notmatch 'DisposeCnTooltipOverlayRuntime\(') {
    if ($plugin -match 'this\.ResetStructuredTooltipUiRuntime\(\);') {
        $plugin = $plugin -replace '(this\.ResetStructuredTooltipUiRuntime\(\);)', "this.DisposeCnTooltipOverlayRuntime();`r`n        `$1"
    }
    elseif ($plugin -match 'public void Dispose\(\)') {
        $plugin = $plugin -replace '(public void Dispose\(\)\s*\{)', "`$1`r`n        this.DisposeCnTooltipOverlayRuntime();"
    }
    else {
        throw "Could not find a safe Dispose insertion point in Echoglossian.cs."
    }
}
else {
    Write-Info "Dispose hook already exists; skipping."
}

Set-Content $pluginPath $plugin -Encoding UTF8

Write-Info "Done. Run dotnet build, then review git diff before committing."
