# Mandarin tooltip overlay module

This module adds a separate ImGui overlay for item/action tooltip translations instead of rewriting FFXIV's native tooltip window.

## What it translates

- Item hovers, including HQ item row-id normalization.
- Action hovers.
- Crafting action hovers.
- General action hovers.
- Trait hovers.

The module reads source text from English Lumina Excel rows, translates it through Echoglossian's existing translation service, caches results, and draws a Chinese overlay near the mouse after a short delay.

## Why overlay mode

Echoglossian's native structured tooltip path for action/item detail windows is intentionally disabled upstream because those detail addons are unstable. This module uses Dalamud's `IGameGui.HoveredItem`, `IGameGui.HoveredAction`, `HoveredItemChanged`, and `HoveredActionChanged` APIs instead, then renders a separate window.

## Apply to your fork

From the Echoglossian repo root:

```powershell
pwsh /path/to/echoglossian-cn-fork-kit/tools/Add-CnTooltipOverlay.ps1 -RepoRoot .
dotnet build .\Echoglossian.csproj -c Release
```

If the script cannot patch your exact upstream version, copy `src/TooltipOverlay/*.cs` into a `TooltipOverlay/` folder in the repo, then manually add these hooks in `Echoglossian.cs`:

```csharp
this.RegisterCnTooltipOverlayRuntime();
```

after `this.RebuildTranslationServiceSafely();`, and:

```csharp
this.DisposeCnTooltipOverlayRuntime();
```

inside `Dispose()` before other UI-runtime disposal calls.

## Config fields added

```csharp
[DefaultValue(true)]
public bool TranslateTooltipOverlay = true;

[DefaultValue(false)]
public bool TooltipOverlayShowOriginal = false;

[DefaultValue(350)]
public int TooltipOverlayDelayMs = 350;

[DefaultValue(560)]
public int TooltipOverlayMaxWidth = 560;

[DefaultValue(1.0f)]
public float TooltipOverlayFontScale = 1.0f;

[DefaultValue(0.96f)]
public float TooltipOverlayBgAlpha = 0.96f;
```

## Known limits

- This does not replace native tooltip text. It adds a translated overlay.
- The overlay uses English as source text. If your client runs in Japanese/French/German, change the `ClientLanguage.English` calls in `GameTooltipTextProvider.cs`.
- Some exotic detail kinds may fall back to the Action sheet or show nothing.
- The module assumes Echoglossian's `TranslationService.TranslateAsync(...)` signature from the current v4 series. If upstream changes that API, update the two calls in `TooltipOverlayTranslatorRuntime.cs`.
